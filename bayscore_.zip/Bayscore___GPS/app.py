from flask import Flask, request, render_template, redirect, session
import sqlite3
from database import create_database

app = Flask(__name__)
app.secret_key = "bay_score_secret_key"

create_database()


def get_db():
    conn = sqlite3.connect("bayscore.db")
    conn.row_factory = sqlite3.Row
    return conn


def login_required():
    return "user_id" in session


# ================= HOME / DASHBOARD =================

@app.route("/")
def home():

    if "user_id" not in session:
        return redirect("/login")

    conn = get_db()

    stats = conn.execute("""
        SELECT COUNT(*) AS total_activities,
               COALESCE(SUM(distance), 0) AS total_distance,
               COALESCE(SUM(score), 0) AS total_score
        FROM activities
        WHERE user_id = ?
    """, (session["user_id"],)).fetchone()

    conn.close()

    return render_template(
        "index.html",
        username=session["username"],
        total_activities=stats["total_activities"],
        total_distance=round(stats["total_distance"], 2),
        total_score=stats["total_score"]
    )


# ================= REGISTER =================

@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        if not username or not password:
            return render_template(
                "register.html",
                error="Username and password are required."
            )

        conn = get_db()

        try:

            conn.execute("""
                INSERT INTO users (username, password)
                VALUES (?, ?)
            """, (username, password))

            conn.commit()
            conn.close()

            return redirect("/login")

        except sqlite3.IntegrityError:

            conn.close()

            return render_template(
                "register.html",
                error="Username already exists."
            )


    return render_template("register.html")


# ================= LOGIN =================

@app.route("/login", methods=["GET", "POST"])
def login():

    # Already logged in
    if "user_id" in session:
        return redirect("/")


    if request.method == "POST":

        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        conn = get_db()

        user = conn.execute("""
            SELECT id, username
            FROM users
            WHERE username = ? AND password = ?
        """, (username, password)).fetchone()

        conn.close()

        if user:

            session.clear()

            session["user_id"] = user["id"]
            session["username"] = user["username"]

            return redirect("/")

        return render_template(
            "login.html",
            error="Invalid username or password."
        )


    return render_template("login.html")


# ================= LOGOUT =================

@app.route("/logout")
def logout():

    session.clear()

    return redirect("/login")


# ================= ADD ACTIVITY =================

@app.route("/add", methods=["POST"])
def add_activity():

    if "user_id" not in session:
        return redirect("/login")

    try:

        activity = request.form.get("activity")

        distance = float(
            request.form.get("distance", 0)
        )

        time = int(
            request.form.get("time", 0)
        )

    except (ValueError, TypeError):

        return "Invalid distance or time."


    if not activity:
        return "Please select an activity."


    if distance <= 0:
        return "Please start GPS and record some distance."


    if time < 0:
        return "Invalid time."


    # ================= BAY SCORE =================

    base_scores = {
        "Running": 100,
        "Walking": 50,
        "Cycling": 80,
        "Swimming": 120,
        "Other": 30
    }

    base_score = base_scores.get(activity, 30)

    distance_bonus = int(distance * 5)

    time_bonus = int(time / 10) * 5

    score = (
        base_score
        + distance_bonus
        + time_bonus
    )


    # ================= SAVE DATABASE =================

    conn = get_db()

    conn.execute("""
        INSERT INTO activities
        (activity, distance, time, score, date, user_id)
        VALUES (?, ?, ?, ?, datetime('now'), ?)
    """, (
        activity,
        distance,
        time,
        score,
        session["user_id"]
    ))

    conn.commit()
    conn.close()


    return render_template(
        "result.html",
        activity=activity,
        distance=distance,
        time=time,
        score=score
    )


# ================= HISTORY =================

@app.route("/history")
def history():

    if "user_id" not in session:
        return redirect("/login")

    conn = get_db()

    activities = conn.execute("""
        SELECT activity,
               distance,
               time,
               score,
               date
        FROM activities
        WHERE user_id = ?
        ORDER BY id DESC
    """, (session["user_id"],)).fetchall()

    conn.close()

    return render_template(
        "history.html",
        activities=activities,
        username=session["username"]
    )


# ================= TOTAL SCORE =================

@app.route("/score")
def total_score():

    if "user_id" not in session:
        return redirect("/login")

    conn = get_db()

    result = conn.execute("""
        SELECT COUNT(*) AS total_activities,
               COALESCE(SUM(distance), 0) AS total_distance,
               COALESCE(SUM(score), 0) AS total_score
        FROM activities
        WHERE user_id = ?
    """, (session["user_id"],)).fetchone()

    conn.close()

    return render_template(
        "score.html",
        username=session["username"],
        total_activities=result["total_activities"],
        total_distance=round(result["total_distance"], 2),
        total_score=result["total_score"]
    )


# ================= RANKING =================

@app.route("/ranking")
def ranking():

    if "user_id" not in session:
        return redirect("/login")

    conn = get_db()

    rankings = conn.execute("""
        SELECT users.username,
               COALESCE(SUM(activities.score), 0) AS total_score
        FROM users
        LEFT JOIN activities
        ON users.id = activities.user_id
        GROUP BY users.id
        ORDER BY total_score DESC
    """).fetchall()

    conn.close()

    return render_template(
        "ranking.html",
        rankings=rankings
    )


# ================= RUN =================

if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=5000,
        debug=True
    )